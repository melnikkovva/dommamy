module backend

go 1.26.0

require (
	filippo.io/edwards25519 v1.2.0
	github.com/go-sql-driver/mysql v1.10.1 
	golang.org/x/crypto v0.59.0 
)
